import { Component } from '@angular/core';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

export class HomePage {

   /** Variables para conexion y progreso de enviado */
   title = 'WebClient';
   connectionStr = 'localhost:8080';
   Uri = 'equalize';
   progress = 0;
 
   selectedFile = null;
 
   public imagePath;
   imgURL: any;
   public message: string;
 
   constructor(private http: HttpClient){}
 
   onFileSelected(event){
     var files = event.target.files;
     if (files === 0){
       return;
     }
     var mimeType = files[0].type;
     if (mimeType.match(/image\/*/) == null) {
       this.message = 'Only images are supported.';
       return;
     }
     var reader = new FileReader();
     this.imagePath = files;
     reader.readAsDataURL(files[0]);
     reader.onload = (_event) => {
       this.imgURL = reader.result;
     }
     this.selectedFile = files[0] as ArrayBuffer; /** Aquí se cambia el tipo de dato a enviar */
     document.getElementById('imageName').style.display = 'inline';
   }
 
   onUpload(){

    const fd = new FormData();
    fd.append('image', this.selectedFile, this.selectedFile.name);

    this.http.post<any>( this.connectionStr+'/'+this.Uri,fd).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress){
        document.getElementById('sendLabel').style.display = 'inline';
        this.progress = Math.round((event.loaded / event.total)*100);
      }else if(event.type === HttpEventType.Response){
        console.log(event);
      }
    });
  }
 
   onEnter(value: string) { this.connectionStr = value; }
 
   setUri(num){
     if(num === 1){
       this.Uri = 'equalize';
     }
     else{
       this.Uri = 'sort';
     }
   }

}
